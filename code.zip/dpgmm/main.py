# coding=utf-8
from __future__ import division
from sklearn import mixture
import os
import numpy as np

np.set_printoptions(threshold='nan')

Dim = 11089


def run():
    list_doc = os.listdir('src_doc')
    doc_num = list_doc.__len__()
    doc_matrix = []
    doc_name = []
    doc_file = []
    for Doc_file in list_doc:
        with open('src_doc/' + Doc_file, 'r') as Doc:
            doc_data = Doc.read()
            doc_name.append(Doc_file)
            doc_file.append(doc_data)
        doc_matrix.append(np.fromstring(doc_data, sep=' '))
    case = mixture.BayesianGaussianMixture(n_components=3, reg_covar=1e-3).fit(doc_matrix).predict(doc_matrix)
    for num in range(np.max(case) + 1):
        os.makedirs('done/' + str(num))
    for num in range(doc_num):
        file_name = doc_name[num]
        temp = doc_file[num]
        Class = case[num]
        with open('done/' + str(Class) + '/' + str(file_name), 'w+') as doc:
            doc.write(str(temp))


if __name__ == '__main__':
    run()
